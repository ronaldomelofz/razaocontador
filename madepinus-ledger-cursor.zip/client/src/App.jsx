import { useEffect, useState } from 'react';

const MONTHS = ['2026-05', '2026-06'];

function fmt(n) {
  return (n ?? 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
}

export default function App() {
  const [month, setMonth] = useState('2026-06');
  const [summary, setSummary] = useState([]);
  const [entries, setEntries] = useState([]);
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    fetch(`/api/ledger/summary?month=${month}`).then((r) => r.json()).then(setSummary);
    const q = statusFilter ? `&status=${statusFilter}` : '';
    fetch(`/api/ledger?month=${month}${q}`).then((r) => r.json()).then(setEntries);
  }, [month, statusFilter]);

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', maxWidth: 1100, margin: '0 auto', padding: 24 }}>
      <h1 style={{ fontFamily: 'Georgia, serif' }}>MADEPINUS — Livro Razão</h1>

      <div style={{ display: 'flex', gap: 8, margin: '16px 0' }}>
        {MONTHS.map((m) => (
          <button key={m} onClick={() => setMonth(m)} style={{ fontWeight: m === month ? 700 : 400 }}>
            {m}
          </button>
        ))}
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">Todos os status</option>
          <option value="matched">Conciliados</option>
          <option value="manual_review">⚠️ Revisão manual</option>
        </select>
        <a href={`/api/export/excel?month=${month}`}>⬇ Excel</a>
        <a href={`/api/export/pdf?month=${month}`}>⬇ PDF</a>
      </div>

      <table border="1" cellPadding="6" style={{ borderCollapse: 'collapse', width: '100%', marginBottom: 24 }}>
        <thead>
          <tr><th>Conta</th><th>Entradas</th><th>Saídas</th><th>Lanç.</th><th>Pendentes</th></tr>
        </thead>
        <tbody>
          {summary.map((s) => (
            <tr key={s.bank_account_id}>
              <td>{s.bank_account_id}</td>
              <td>{fmt(s.entradas)}</td>
              <td>{fmt(s.saidas)}</td>
              <td>{s.n}</td>
              <td>{s.pendentes > 0 ? `⚠️ ${s.pendentes}` : '✅'}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <table border="1" cellPadding="4" style={{ borderCollapse: 'collapse', width: '100%', fontSize: 12 }}>
        <thead>
          <tr><th>Data</th><th>Histórico</th><th>Débito</th><th>Crédito</th><th>Valor</th><th>Categoria</th><th>Status</th></tr>
        </thead>
        <tbody>
          {entries.map((e) => (
            <tr key={e.id} style={{ background: e.status === 'manual_review' ? '#FDECC8' : 'transparent' }}>
              <td>{e.entry_date}</td>
              <td>{e.description}</td>
              <td>{e.debit_account}</td>
              <td>{e.credit_account}</td>
              <td>{fmt(e.amount)}</td>
              <td>{e.category}</td>
              <td>{e.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
