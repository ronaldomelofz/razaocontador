# MADEPINUS — Livro Razão Digital

Sistema de conciliação contábil automática (partidas dobradas) para Falcão & Frazão Ltda (MADEPINUS).
Cruza extratos bancários, XML fiscal (NF-e/NFC-e), boletos e relatórios Alterdata, gera Livro Razão
e disponibiliza via web para acesso do contador (visualização + export Excel/PDF).

## Stack
- **Backend:** Node.js + Express + SQLite (better-sqlite3) — zero custo, roda local ou free-tier (Railway/Render).
- **Frontend:** React (Vite) + Tailwind.
- **Parsers:** OFX, CSV/TXT de extrato, XLSX (Alterdata), XML NF-e/NFC-e, PDF (pdf-parse, texto nativo).
- **Auth:** Magic-link simples (sem custo) para acesso do contador (read-only).
- **Export:** exceljs (Excel), pdfkit (PDF).

## Estrutura
```
server/
  src/
    parsers/       # 1 parser por tipo de fonte (banco, xml, alterdata, pdf)
    engine/        # classificação (regras) + matching/conciliação
    routes/        # API REST
    db/            # schema + migrations SQLite
    utils/         # helpers (datas, valores BRL, logging)
  data/uploads/     # arquivos brutos enviados (gitignored)
client/
  src/
    pages/          # Dashboard, Lançamentos, Conciliação, Contador (view)
    components/
    styles/
docs/
  PLANO_DE_CONTAS.md
  REGRAS_CLASSIFICACAO.md
```

## Como rodar (Cursor AI)
1. Abra a pasta no Cursor.
2. `cd server && npm install && npm run dev` (porta 3001)
3. `cd client && npm install && npm run dev` (porta 5173)
4. Suba arquivos via `/api/upload` ou copie para `server/data/uploads/<banco>/<mes>/`.
5. Rode o pipeline: `npm run process -- --month=2026-06` (dentro de `server/`).

## Próximos passos sugeridos no Cursor
- Implementar parser real de XML NF-e/NFC-e (`server/src/parsers/xmlFiscal.js` — stub pronto).
- Implementar OCR de PDFs escaneados (`server/src/parsers/pdfScan.js` — usar tesseract.js).
- Completar `docs/PLANO_DE_CONTAS.md` com códigos reais do Alterdata (balancete anexo já mapeado parcialmente).
- Adicionar autenticação real (magic link via Resend/Nodemailer, free tier).
- Deploy: Railway (backend+SQLite) + Vercel (frontend), ambos free tier.

## Dados já processados (referência)
`docs/DADOS_PROCESSADOS.md` lista o que já foi conciliado manualmente (Itaú, BB, Inter parcial)
para servir de gabarito de validação do pipeline automático.
