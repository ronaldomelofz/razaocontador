// server/src/routes/export.js
import { Router } from 'express';
import Database from 'better-sqlite3';
import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database(path.join(__dirname, '../../data/madepinus.db'));
const router = Router();

// GET /api/export/excel?month=2026-06
router.get('/excel', async (req, res) => {
  const { month } = req.query;
  const rows = db.prepare(`
    SELECT le.entry_date, le.description, le.debit_account, le.credit_account, le.amount, le.category, le.status,
           rt.bank_account_id
    FROM ledger_entries le
    JOIN raw_transactions rt ON rt.id = le.raw_transaction_id
    WHERE le.entry_date LIKE ?
    ORDER BY le.entry_date
  `).all(`${month}%`);

  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet(`Razão ${month}`);
  ws.columns = [
    { header: 'Data', key: 'entry_date', width: 12 },
    { header: 'Histórico', key: 'description', width: 40 },
    { header: 'Conta Débito', key: 'debit_account', width: 20 },
    { header: 'Conta Crédito', key: 'credit_account', width: 20 },
    { header: 'Valor (R$)', key: 'amount', width: 14, style: { numFmt: '#,##0.00' } },
    { header: 'Categoria', key: 'category', width: 32 },
    { header: 'Status', key: 'status', width: 16 },
    { header: 'Banco', key: 'bank_account_id', width: 16 },
  ];
  ws.getRow(1).font = { bold: true };
  rows.forEach((r) => ws.addRow(r));

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="livro_razao_${month}.xlsx"`);
  await wb.xlsx.write(res);
  res.end();
});

// GET /api/export/pdf?month=2026-06 (resumo executivo)
router.get('/pdf', (req, res) => {
  const { month } = req.query;
  const summary = db.prepare(`
    SELECT rt.bank_account_id,
           SUM(CASE WHEN le.debit_account = rt.bank_account_id THEN le.amount ELSE 0 END) AS entradas,
           SUM(CASE WHEN le.credit_account = rt.bank_account_id THEN le.amount ELSE 0 END) AS saidas
    FROM ledger_entries le JOIN raw_transactions rt ON rt.id = le.raw_transaction_id
    WHERE le.entry_date LIKE ? GROUP BY rt.bank_account_id
  `).all(`${month}%`);

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="resumo_${month}.pdf"`);
  const doc = new PDFDocument();
  doc.pipe(res);
  doc.fontSize(16).text(`MADEPINUS — Resumo Razão ${month}`, { underline: true });
  doc.moveDown();
  summary.forEach((s) => {
    doc.fontSize(11).text(`${s.bank_account_id}: entradas R$ ${s.entradas.toFixed(2)} · saídas R$ ${s.saidas.toFixed(2)}`);
  });
  doc.end();
});

export default router;
