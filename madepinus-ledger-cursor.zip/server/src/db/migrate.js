import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, '../../data/madepinus.db');
const schemaPath = path.join(__dirname, 'schema.sql');

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.exec(fs.readFileSync(schemaPath, 'utf-8'));

// Seed: contas bancárias conhecidas
const seedAccounts = db.prepare(`
  INSERT OR IGNORE INTO bank_accounts (id, bank, agency, account_number) VALUES (?, ?, ?, ?)
`);
const accounts = [
  ['itau-29660-2', 'Itaú', '4826', '29660-2'],
  ['itau-57563-6', 'Itaú', '8840', '57563-6'],
  ['itau-31689-7', 'Itaú', '4826', '31689-7'],
  ['itau-05068-7', 'Itaú', '0575', '05068-7'],
  ['itau-33489-0', 'Itaú', '4826', '33489-0'],
  ['bb-847-8', 'Banco do Brasil', '3219-0', '847-8'],
  ['inter-9908006-0', 'Banco Inter', '0001-9', '9908006-0'],
  ['bnb-119424-3', 'BNB', '56', '119424-3'],
  ['mercadopago', 'Mercado Pago', null, null],
  ['automais', 'Aplicação Auto Mais', null, null],
];
for (const a of accounts) seedAccounts.run(...a);

console.log('Migração concluída:', dbPath);
db.close();
